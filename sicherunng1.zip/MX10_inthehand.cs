using System;
using System.Linq;
using System.Threading.Tasks;
using InTheHand.Bluetooth;
using System.Drawing;
using System.Drawing.Imaging;

namespace MX10ThermalPrinter
{
    public class MX10Printer
    {
        private const int PRINTER_WIDTH = 384;
        private static readonly BluetoothUuid SERVICE_UUID = BluetoothUuid.FromShortId(0xAE30);
        private static readonly BluetoothUuid CHAR_UUID_DATA = BluetoothUuid.FromShortId(0xAE01);

        private RemoteGattServer? _server;
        private GattCharacteristic? _dataCharacteristic;
        private BluetoothDevice? _device;

        public string? DeviceName { get; private set; }
        public string? MacAddress { get; private set; }
        public bool IsConnected => _server?.IsConnected ?? false;

        public async Task<bool> ScanAndConnectAsync(string printerName, int timeoutSeconds = 10)
        {
            try
            {
                Console.WriteLine($"Suche nach Gerät '{printerName}'...");

                BluetoothDevice? foundDevice = null;

                void Bluetooth_AdvertisementReceived(object? sender, BluetoothAdvertisingEvent e)
                {
                    if (e.Device.Name == printerName)
                    {
                        foundDevice = e.Device;
                    }
                }

                Bluetooth.AdvertisementReceived += Bluetooth_AdvertisementReceived;

                var options = new BluetoothLEScanOptions();
                var filter = new BluetoothLEScanFilter { Name = printerName };
                options.Filters.Add(filter);

                var scan = await Bluetooth.RequestLEScanAsync(options);

                // Warte bis Gerät gefunden oder Timeout
                for (int i = 0; i < timeoutSeconds * 5; i++) // 5 checks per second
                {
                    await Task.Delay(200);
                    if (foundDevice != null) break;
                }

                scan.Stop();
                Bluetooth.AdvertisementReceived -= Bluetooth_AdvertisementReceived;

                if (foundDevice == null)
                {
                    Console.WriteLine($"Kein {printerName} Gerät gefunden.");
                    return false;
                }

                _device = foundDevice;
                return await ConnectToDeviceAsync(_device);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Scan-Fehler: {ex.Message}");
                return false;
            }
        }

        public async Task<bool> ConnectByMacAsync(string macAddress)
        {
            try
            {
                Console.WriteLine($"Versuche Verbindung zu gespeicherter MAC: {macAddress}");

                BluetoothDevice? foundDevice = null;
                string normalizedMac = NormalizeMac(macAddress);

                void Bluetooth_AdvertisementReceived(object? sender, BluetoothAdvertisingEvent e)
                {
                    if (!string.IsNullOrEmpty(e.Device.Id) &&
                        NormalizeMac(e.Device.Id).Equals(normalizedMac, StringComparison.OrdinalIgnoreCase))
                    {
                        foundDevice = e.Device;
                    }
                }

                Bluetooth.AdvertisementReceived += Bluetooth_AdvertisementReceived;

                var options = new BluetoothLEScanOptions();
                options.AcceptAllAdvertisements = true;
                
                var scan = await Bluetooth.RequestLEScanAsync(options);

                // Warte bis Gerät gefunden (10 Sekunden)
                for (int i = 0; i < 50; i++)
                {
                    await Task.Delay(200);
                    if (foundDevice != null) break;
                }

                scan.Stop();
                Bluetooth.AdvertisementReceived -= Bluetooth_AdvertisementReceived;

                if (foundDevice == null)
                {
                    Console.WriteLine("Gerät mit gespeicherter MAC nicht gefunden.");
                    return false;
                }

                _device = foundDevice;
                return await ConnectToDeviceAsync(_device);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Verbindungsfehler: {ex.Message}");
                return false;
            }
        }

        private async Task<bool> ConnectToDeviceAsync(BluetoothDevice device)
        {
            try
            {
                DeviceName = device.Name;
                MacAddress = device.Id;

                Console.WriteLine($"Verbinde mit: {DeviceName} ({MacAddress})");

                _server = device.Gatt;
                await _server.ConnectAsync();

                if (!_server.IsConnected)
                {
                    Console.WriteLine("GATT-Verbindung fehlgeschlagen.");
                    return false;
                }

                Console.WriteLine("GATT verbunden, suche Service...");

                var service = await _server.GetPrimaryServiceAsync(SERVICE_UUID);
                if (service == null)
                {
                    Console.WriteLine($"Service {SERVICE_UUID} nicht gefunden.");
                    return false;
                }

                Console.WriteLine("Service gefunden, suche Charakteristik...");

                _dataCharacteristic = await service.GetCharacteristicAsync(CHAR_UUID_DATA);
                if (_dataCharacteristic == null)
                {
                    Console.WriteLine($"Charakteristik {CHAR_UUID_DATA} nicht gefunden.");
                    return false;
                }

                Console.WriteLine("Charakteristik gefunden, Verbindung erfolgreich!");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Verbindungsfehler: {ex.Message}");
                return false;
            }
        }

        public void Disconnect()
        {
            try
            {
                _dataCharacteristic = null;
                _server?.Disconnect();
                _device = null;
                Console.WriteLine("Verbindung getrennt.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Fehler beim Trennen: {ex.Message}");
            }
        }

        public async Task SetEnergyAsync(int energy)
        {
            await WriteCatCommandD16Async(0xAF, (ushort)energy);
        }

        public async Task FeedAsync(int lines)
        {
            if (lines < 0)
            {
                // Retract
                ushort value = (ushort)Math.Abs(lines);
                await WriteCatCommandD16Async(0xA0, value);
            }
            else
            {
                // Feed
                ushort value = (ushort)lines;
                await WriteCatCommandD16Async(0xA1, value);
            }
        }

        public async Task PrintGraphicsAsync(Bitmap bitmap)
        {
            // Set drawing mode to image (0)
            await WriteCatCommandD8Async(0xBE, 0);

            int height = bitmap.Height;

            for (int y = 0; y < height; y++)
            {
                byte[] lineData = new byte[PRINTER_WIDTH / 8];

                for (int x = 0; x < PRINTER_WIDTH; x++)
                {
                    var pixel = bitmap.GetPixel(x, y);
                    bool isBlack = pixel.GetBrightness() < 0.5;

                    if (isBlack)
                    {
                        int byteIndex = x / 8;
                        int bitIndex = 7 - (x % 8);
                        lineData[byteIndex] |= (byte)(1 << bitIndex);
                    }
                }

                // Mirror bits for CAT printer
                for (int i = 0; i < lineData.Length; i++)
                {
                    lineData[i] = MirrorByte(lineData[i]);
                }

                await SendScanlineAsync(lineData);
            }
        }

        private async Task SendScanlineAsync(byte[] data)
        {
            int len = data.Length;
            byte[] packet = new byte[8 + len];

            packet[0] = 0x51;
            packet[1] = 0x78;
            packet[2] = 0xA2; // Graphics data, uncompressed
            packet[3] = 0x00;
            packet[4] = (byte)(len & 0xFF);
            packet[5] = (byte)(len >> 8);

            Array.Copy(data, 0, packet, 6, len);

            packet[6 + len] = CalculateChecksum(data);
            packet[6 + len + 1] = 0xFF;

            await WriteDataAsync(packet);
        }

        private async Task WriteCatCommandD8Async(byte command, byte data)
        {
            byte[] packet = new byte[9];
            packet[0] = 0x51;
            packet[1] = 0x78;
            packet[2] = command;
            packet[3] = 0x00;
            packet[4] = 0x01;
            packet[5] = 0x00;
            packet[6] = data;
            packet[7] = CalculateChecksum(new byte[] { data });
            packet[8] = 0xFF;

            await WriteDataAsync(packet);
        }

        private async Task WriteCatCommandD16Async(byte command, ushort data)
        {
            byte[] packet = new byte[10];
            packet[0] = 0x51;
            packet[1] = 0x78;
            packet[2] = command;
            packet[3] = 0x00;
            packet[4] = 0x02;
            packet[5] = 0x00;
            packet[6] = (byte)(data & 0xFF);
            packet[7] = (byte)(data >> 8);
            packet[8] = CalculateChecksum(new byte[] { packet[6], packet[7] });
            packet[9] = 0xFF;

            await WriteDataAsync(packet);
        }
        
          private async Task WriteDataAsync(byte[] data)
        {
            if (_dataCharacteristic == null || !IsConnected)
                throw new InvalidOperationException("Nicht verbunden");
            
         await _dataCharacteristic.WriteValueWithoutResponseAsync(data);
        }
/*
        private async Task WriteDataAsync(byte[] data)
        {
            if (_dataCharacteristic == null || !IsConnected)
                throw new InvalidOperationException("Nicht verbunden");

            // Send in chunks of 20 bytes max for BLE reliability
            int offset = 0;
            while (offset < data.Length)
            {
                int chunkSize = Math.Min(20, data.Length - offset);
                byte[] chunk = new byte[chunkSize];
                Array.Copy(data, offset, chunk, 0, chunkSize);

                try
                {
                    await _dataCharacteristic.WriteValueWithoutResponseAsync(chunk);
                }
                catch (Exception ex)
                {
                    throw new Exception($"Schreibfehler: {ex.Message}", ex);
                }

                offset += chunkSize;
               // await Task.Delay(10); // Optional: Small delay for reliability
            }
        }
*/
        private static string NormalizeMac(string mac)
        {
            return mac.Replace(":", "").Replace("-", "").Replace(" ", "").ToUpperInvariant();
        }

        private static byte CalculateChecksum(byte[] data)
        {
            byte cs = 0;
            foreach (byte b in data)
            {
                cs = CRC8_TABLE[cs ^ b];
            }
            return cs;
        }

        private static byte MirrorByte(byte b)
        {
            return MIRROR_TABLE[b];
        }

        // CRC8 Lookup Table
        private static readonly byte[] CRC8_TABLE = new byte[] {
            0x00, 0x07, 0x0e, 0x09, 0x1c, 0x1b, 0x12, 0x15, 0x38, 0x3f, 0x36, 0x31, 0x24, 0x23, 0x2a, 0x2d,
            0x70, 0x77, 0x7e, 0x79, 0x6c, 0x6b, 0x62, 0x65, 0x48, 0x4f, 0x46, 0x41, 0x54, 0x53, 0x5a, 0x5d,
            0xe0, 0xe7, 0xee, 0xe9, 0xfc, 0xfb, 0xf2, 0xf5, 0xd8, 0xdf, 0xd6, 0xd1, 0xc4, 0xc3, 0xca, 0xcd,
            0x90, 0x97, 0x9e, 0x99, 0x8c, 0x8b, 0x82, 0x85, 0xa8, 0xaf, 0xa6, 0xa1, 0xb4, 0xb3, 0xba, 0xbd,
            0xc7, 0xc0, 0xc9, 0xce, 0xdb, 0xdc, 0xd5, 0xd2, 0xff, 0xf8, 0xf1, 0xf6, 0xe3, 0xe4, 0xed, 0xea,
            0xb7, 0xb0, 0xb9, 0xbe, 0xab, 0xac, 0xa5, 0xa2, 0x8f, 0x88, 0x81, 0x86, 0x93, 0x94, 0x9d, 0x9a,
            0x27, 0x20, 0x29, 0x2e, 0x3b, 0x3c, 0x35, 0x32, 0x1f, 0x18, 0x11, 0x16, 0x03, 0x04, 0x0d, 0x0a,
            0x57, 0x50, 0x59, 0x5e, 0x4b, 0x4c, 0x45, 0x42, 0x6f, 0x68, 0x61, 0x66, 0x73, 0x74, 0x7d, 0x7a,
            0x89, 0x8e, 0x87, 0x80, 0x95, 0x92, 0x9b, 0x9c, 0xb1, 0xb6, 0xbf, 0xb8, 0xad, 0xaa, 0xa3, 0xa4,
            0xf9, 0xfe, 0xf7, 0xf0, 0xe5, 0xe2, 0xeb, 0xec, 0xc1, 0xc6, 0xcf, 0xc8, 0xdd, 0xda, 0xd3, 0xd4,
            0x69, 0x6e, 0x67, 0x60, 0x75, 0x72, 0x7b, 0x7c, 0x51, 0x56, 0x5f, 0x58, 0x4d, 0x4a, 0x43, 0x44,
            0x19, 0x1e, 0x17, 0x10, 0x05, 0x02, 0x0b, 0x0c, 0x21, 0x26, 0x2f, 0x28, 0x3d, 0x3a, 0x33, 0x34,
            0x4e, 0x49, 0x40, 0x47, 0x52, 0x55, 0x5c, 0x5b, 0x76, 0x71, 0x78, 0x7f, 0x6a, 0x6d, 0x64, 0x63,
            0x3e, 0x39, 0x30, 0x37, 0x22, 0x25, 0x2c, 0x2b, 0x06, 0x01, 0x08, 0x0f, 0x1a, 0x1d, 0x14, 0x13,
            0xae, 0xa9, 0xa0, 0xa7, 0xb2, 0xb5, 0xbc, 0xbb, 0x96, 0x91, 0x98, 0x9f, 0x8a, 0x8d, 0x84, 0x83,
            0xde, 0xd9, 0xd0, 0xd7, 0xc2, 0xc5, 0xcc, 0xcb, 0xe6, 0xe1, 0xe8, 0xef, 0xfa, 0xfd, 0xf4, 0xf3
        };

        // Bit Mirror Lookup Table
        private static readonly byte[] MIRROR_TABLE = new byte[] {
            0x00, 0x80, 0x40, 0xC0, 0x20, 0xA0, 0x60, 0xE0, 0x10, 0x90, 0x50, 0xD0, 0x30, 0xB0, 0x70, 0xF0,
            0x08, 0x88, 0x48, 0xC8, 0x28, 0xA8, 0x68, 0xE8, 0x18, 0x98, 0x58, 0xD8, 0x38, 0xB8, 0x78, 0xF8,
            0x04, 0x84, 0x44, 0xC4, 0x24, 0xA4, 0x64, 0xE4, 0x14, 0x94, 0x54, 0xD4, 0x34, 0xB4, 0x74, 0xF4,
            0x0C, 0x8C, 0x4C, 0xCC, 0x2C, 0xAC, 0x6C, 0xEC, 0x1C, 0x9C, 0x5C, 0xDC, 0x3C, 0xBC, 0x7C, 0xFC,
            0x02, 0x82, 0x42, 0xC2, 0x22, 0xA2, 0x62, 0xE2, 0x12, 0x92, 0x52, 0xD2, 0x32, 0xB2, 0x72, 0xF2,
            0x0A, 0x8A, 0x4A, 0xCA, 0x2A, 0xAA, 0x6A, 0xEA, 0x1A, 0x9A, 0x5A, 0xDA, 0x3A, 0xBA, 0x7A, 0xFA,
            0x06, 0x86, 0x46, 0xC6, 0x26, 0xA6, 0x66, 0xE6, 0x16, 0x96, 0x56, 0xD6, 0x36, 0xB6, 0x76, 0xF6,
            0x0E, 0x8E, 0x4E, 0xCE, 0x2E, 0xAE, 0x6E, 0xEE, 0x1E, 0x9E, 0x5E, 0xDE, 0x3E, 0xBE, 0x7E, 0xFE,
            0x01, 0x81, 0x41, 0xC1, 0x21, 0xA1, 0x61, 0xE1, 0x11, 0x91, 0x51, 0xD1, 0x31, 0xB1, 0x71, 0xF1,
            0x09, 0x89, 0x49, 0xC9, 0x29, 0xA9, 0x69, 0xE9, 0x19, 0x99, 0x59, 0xD9, 0x39, 0xB9, 0x79, 0xF9,
            0x05, 0x85, 0x45, 0xC5, 0x25, 0xA5, 0x65, 0xE5, 0x15, 0x95, 0x55, 0xD5, 0x35, 0xB5, 0x75, 0xF5,
            0x0D, 0x8D, 0x4D, 0xCD, 0x2D, 0xAD, 0x6D, 0xED, 0x1D, 0x9D, 0x5D, 0xDD, 0x3D, 0xBD, 0x7D, 0xFD,
            0x03, 0x83, 0x43, 0xC3, 0x23, 0xA3, 0x63, 0xE3, 0x13, 0x93, 0x53, 0xD3, 0x33, 0xB3, 0x73, 0xF3,
            0x0B, 0x8B, 0x4B, 0xCB, 0x2B, 0xAB, 0x6B, 0xEB, 0x1B, 0x9B, 0x5B, 0xDB, 0x3B, 0xBB, 0x7B, 0xFB,
            0x07, 0x87, 0x47, 0xC7, 0x27, 0xA7, 0x67, 0xE7, 0x17, 0x97, 0x57, 0xD7, 0x37, 0xB7, 0x77, 0xF7,
            0x0F, 0x8F, 0x4F, 0xCF, 0x2F, 0xAF, 0x6F, 0xEF, 0x1F, 0x9F, 0x5F, 0xDF, 0x3F, 0xBF, 0x7F, 0xFF
        };
    }
}